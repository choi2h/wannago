package com.wannago;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WannagoServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(WannagoServerApplication.class, args);
    }

}
