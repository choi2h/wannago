package com.wannago.qna.service;

import com.wannago.qna.dto.AskRequestDto;
import com.wannago.qna.dto.AskResponseDto;
import com.wannago.qna.entity.Ask;
import com.wannago.qna.repository.AskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AskService {

    private final AskRepository askRepository;

    @Transactional
    public Long createAsk(AskRequestDto dto) {
        Ask ask = new Ask(
                null,
                dto.getCategory(),
                dto.getAuthor(),
                dto.getTitle(),
                dto.getContents(),
                false,   // isAccepted 초기값 false
                null,
                null
        );
        Ask saved = askRepository.save(ask);
        return saved.getId();
    }
    // 질문수정
    @Transactional
    public void updateAsk(Long id, AskRequestDto dto, String loginId) {
        Ask ask = askRepository.findById(id)
                .orElseThrow(() -> new CustomException(CustomErrorCode.NOT_FOUND));

        if (!ask.getAuthor().equals(loginId)) {
            throw new CustomException(CustomErrorCode.NO_PERMISSION);
        }

        ask.update(dto.getCategory(), dto.getTitle(), dto.getContents());
    }

    // 질문삭제
    @Transactional
    public void deleteAsk(Long id, String loginId) {
        Ask ask = askRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 질문이 없습니다. id=" + id));

        if (!ask.getAuthor().equals(loginId)) {
            throw new CustomException(CustomErrorCode.NO_PERMISSION);
        }

        askRepository.delete(ask);
    }

    @Transactional(readOnly = true)
    public List<AskResponseDto> getAskList() {
        return askRepository.findAll().stream()
                .map(ask -> new AskResponseDto(
                        ask.getId(),
                        ask.getCategory(),
                        ask.getAuthor(),
                        ask.getTitle(),
                        ask.getCreatedDate()))
                .collect(Collectors.toList());
    }
}
