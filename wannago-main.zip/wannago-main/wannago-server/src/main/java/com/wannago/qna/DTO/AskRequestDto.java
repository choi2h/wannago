// Ask Request DTO
package com.wannago.qna.dto;

import com.wannago.qna.entity.Category;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AskRequestDto {
    private Category category;
    private String author;
    private String title;
    private String contents;
}
