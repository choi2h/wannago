package com.wannago.qna.entity;

public enum Category {
    ACTIVITY, FOOD, LOCATION, OTHER;
}
