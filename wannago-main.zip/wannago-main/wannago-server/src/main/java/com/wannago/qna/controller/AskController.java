// Ask 컨트롤러
package com.wannago.qna.controller;

import com.wannago.qna.dto.AskRequestDto;
import com.wannago.qna.dto.AskResponseDto;
import com.wannago.qna.service.AskService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/asks")
@RequiredArgsConstructor
public class AskController {

    private final AskService askService;

    @PostMapping
    public Long createAsk(@RequestBody AskRequestDto dto) {
        return askService.createAsk(dto);
    }

    @PutMapping("/{id}")
    public void updateAsk(@PathVariable Long id, @RequestBody AskRequestDto dto, HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        String loginId = jwtTokenResolver.getUsernameFromToken(token);
        askService.updateAsk(id, dto, loginId);
    }

    @DeleteMapping("/{id}")
    public void deleteAsk(@PathVariable Long id, HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        String loginId = jwtTokenResolver.getUsernameFromToken(token);
        askService.deleteAsk(id, loginId);
    }

    @GetMapping
    public List<AskResponseDto> getAskList() {
        return askService.getAskList();
    }
}
