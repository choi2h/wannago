// Ask Response dto
// 질문목록 dto
package com.wannago.qna.dto;

import com.wannago.qna.entity.Category;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class AskResponseDto {
    private Long id;
    private Category category;
    private String author;
    private String title;
    private LocalDateTime createdDate;
}
